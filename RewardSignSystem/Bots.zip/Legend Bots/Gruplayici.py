from getpass import getpass
import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
import pyautogui
import pyperclip

## Legend Online Helper için özel olarak geliştirilmiştir Bot 2
## Hesapları otomatik gruplamak için yapılmıştır.
flag = False
delNum = 0
linkTemp = ""
print("\n")
print("█░░ █▀▀ █▀▀ █▀▀ █▄░█ █▀▄   █▀█ █▄░█ █░░ █ █▄░█ █▀▀   █░█ █▀▀ █░░ █▀█ █▀▀ █▀█")
print("█▄▄ ██▄ █▄█ ██▄ █░▀█ █▄▀   █▄█ █░▀█ █▄▄ █ █░▀█ ██▄   █▀█ ██▄ █▄▄ █▀▀ ██▄ █▀▄")
print("\nHesap Gruplama Botu Powered by AthenaSenior \n\n")
print("\nKod çoğaltılamaz veya değiştirilemez. Tespit edildiği takdirde adli işlemler başlatılır. Bol Farmlar dileriz..\n")
print("\n______________________________________________________________________________________________________________________\n")
emailFirstPlace = input("- Email'in sol tarafı? \n Örnek: asdas1@gmail.com, asdas2@gmail.com... ise 'asdas' girin. \n **** : ")
print("\n\n")
emailType = input("- Email'in sağ tarafı? \n "+ emailFirstPlace +"1@****** \n **** : ")
print("\n\n")
numberOfAccount = int(input("- Hesap sayısı: "))
password = getpass("Şifre: ")
baslangicSayisi = int(input("- Kaçıncı hesaptan başlansın?: "))
if numberOfAccount % 4 == 0 and numberOfAccount <= 100 and numberOfAccount > 0:
    for i in range(baslangicSayisi, (baslangicSayisi + numberOfAccount)):
        email = emailFirstPlace + str(i) + "@" + emailType
        driver = webdriver.Chrome()
        link = "https://www.oasgames.com/?a=ucenter&m=login"
        if(i % 4 == 1):
            linkTemp = "https://newserver79-lotr.oasgames.com/activity"
        driver.get(link)
        while True:
            try:
                if not flag:
                    #driver.find_element(By.XPATH, "/html/body/div[2]/div[1]/div[1]/ul/li[3]/a").click()
                    #frame = driver.find_element(By.ID, "login_reg_page")
                    time.sleep(3)
                    #driver.switch_tjuo.frame(frame)
                    driver.find_element(By.XPATH, "//*[@id='user_email']").send_keys(email)
                    time.sleep(1)
                    pyautogui.click(848,543)
                    time.sleep(0.5)
                    driver.find_element(By.XPATH, '//*[@id="user_password"]').send_keys(password)
                    time.sleep(0.5)
                    driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/div[2]/div[1]/a").click()
                    time.sleep(1)
                    driver.get(linkTemp)
                    time.sleep(1)
                    #driver.switch_to.default_content()
                if((i - 1) % 4 == 0):
                    while True:
                        try:
                            pyautogui.click(628,862)
                            time.sleep(1)
                            pyautogui.click(621,911)
                            time.sleep(1)
                            pyautogui.click(874,867)
                            time.sleep(4.5)
                            driver.find_element(By.CLASS_NAME, "login_success_last").click()
                            flag = False
                            break
                        except Exception:
                            flag = True
                            driver.refresh()
                            continue
                break
            except Exception:
                if not flag:
                    driver.refresh()
                    time.sleep(5)
                continue
        if((i - 1) % 4 == 0 or i == 1):
           window_before = driver.window_handles[0]
           pyautogui.click(1302,951)
           time.sleep(0.5)
           pyautogui.click(1302,951)
           time.sleep(0.5)
           pyautogui.click(1302,951)
           time.sleep(0.5)
           pyautogui.click(1302,951)
           time.sleep(0.5)
           pyautogui.click(1302,951)
           time.sleep(0.5)
           pyautogui.hotkey('f12')
           time.sleep(3)
           pyautogui.click(1292,249)
           time.sleep(0.5)
           pyautogui.click(819,200)
           time.sleep(0.5)
           pyautogui.click(679,235)
           time.sleep(1)
           pyautogui.hotkey('f12')
           time.sleep(2)
           pyautogui.click(666,478)
           time.sleep(3)
           while True:
                try:
                    window_after = driver.window_handles[1]
                    driver.switch_to.window(window_after)
                    driver.find_element(By.XPATH, '//*[@id="email"]').click()
                    break
                except Exception:
                    driver.refresh()
                    driver.switch_to.default_content()
                    time.sleep(2)
                    pyautogui.click(666,478)
                    continue
           pyautogui.click(1022,18)
           time.sleep(2)
           pyautogui.hotkey('f12')
           time.sleep(2)
           pyautogui.click(819,200)
           time.sleep(0.5)
           pyautogui.click(1236, 384)
           time.sleep(1)
           #pyautogui.click(1219,505)
           time.sleep(0.5)
           ''' console.log()
           pyautogui.click(437,359)
           time.sleep(1)
           pyautogui.click(497,456)
           time.sleep(1)
           pyautogui.click(727,485)
           time.sleep(2)
           pyautogui.hotkey('ctrl', 'f')
           time.sleep(1)
           pyperclip.copy("Error while")
           time.sleep(1)
           pyautogui.hotkey('ctrl', 'v')
           time.sleep(1)
           pyautogui.click(849,681)
           time.sleep(1)
           '''
           while delNum < 22:
                pyautogui.hotkey('del')
                time.sleep(0.25)
                delNum = delNum + 1
           pyperclip.copy("share['link']")
           time.sleep(0.5)
           pyautogui.hotkey('ctrl', 'v')
           time.sleep(1)
           pyautogui.click(733,526)
           pyautogui.hotkey('a')
           time.sleep(0.1)
           pyautogui.hotkey('l')
           time.sleep(0.1)
           pyautogui.hotkey('l')
           time.sleep(0.1)
           pyautogui.hotkey('o')
           time.sleep(0.1)
           pyautogui.hotkey('w')
           time.sleep(0.1)
           pyautogui.hotkey(' ')
           time.sleep(0.1)
           pyautogui.hotkey('p')
           time.sleep(0.1)
           pyautogui.hotkey('a')
           time.sleep(0.1)
           pyautogui.hotkey('s')
           time.sleep(0.1)
           pyautogui.hotkey('t')
           time.sleep(0.1)
           pyautogui.hotkey('i')
           time.sleep(0.1)
           pyautogui.hotkey('n')
           time.sleep(0.1)
           pyautogui.hotkey('g')
           time.sleep(0.1)
           pyautogui.click(1200,571)
           time.sleep(0.5)
           pyautogui.hotkey('ctrl', 'v')
           time.sleep(0.5)
           pyautogui.hotkey('ctrl', 's')
           time.sleep(0.5)
           pyautogui.click(839,274)
           time.sleep(0.5)
           pyautogui.click(679,312)
           time.sleep(0.5)
           pyautogui.hotkey('f12')
           time.sleep(1.5)
           pyautogui.click(666,478)
           time.sleep(3)
           pyautogui.click(1022,18)
           time.sleep(2)
           pyautogui.hotkey('f12')
           time.sleep(2)
           pyautogui.click(798,349)
           time.sleep(1)
           pyautogui.click(798,400)
           time.sleep(1)
           pyautogui.click(803,442)
           time.sleep(1)
           pyautogui.click(433,83)
           pyautogui.hotkey('ctrl', 'c')
           newlink = pyperclip.paste()
           linkTemp = newlink
        else: #Daveti kabul et.
            driver.switch_to.default_content()
            while True:
                try:
                    driver.find_element(By.XPATH, "/html/body/div[2]/div[5]/div/div/p").click()
                    pyautogui.click(575, 778)
                    time.sleep(3)
                except:
                    break
        delNum = 0
        driver.switch_to.window(driver.window_handles[-1])
        driver.close()
        time.sleep(2)     
else:
    print("Hata! Hesap sayısı 4ün katı olmalı, 100 den fazla olmamalı veya 0dan az olmamalıdır.")
    print("\n\n")
    os.system("PAUSE")