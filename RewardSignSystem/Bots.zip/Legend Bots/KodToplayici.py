from getpass import getpass
import os
import time
import pyautogui
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
## Legend Online Helper için özel olarak geliştirilmiştir Bot 4
## Ödül Toplamak için yapılmıştır.
print("\n")
print("█░░ █▀▀ █▀▀ █▀▀ █▄░█ █▀▄   █▀█ █▄░█ █░░ █ █▄░█ █▀▀   █░█ █▀▀ █░░ █▀█ █▀▀ █▀█")
print("█▄▄ ██▄ █▄█ ██▄ █░▀█ █▄▀   █▄█ █░▀█ █▄▄ █ █░▀█ ██▄   █▀█ ██▄ █▄▄ █▀▀ ██▄ █▀▄")
print("\nYoklama Alma Botu Powered by AthenaSenior \n\n")
print("\nKod çoğaltılamaz veya değiştirilemez. Tespit edildiği takdirde adli işlemler başlatılır. Bol Farmlar dileriz..\n")
print("\n______________________________________________________________________________________________________________________\n")
emailFirstPlace = input("- Email'in sol tarafı? \n Örnek: asdas1@gmail.com, asdas2@gmail.com... ise 'asdas' girin. \n **** : ")
print("\n\n")
emailType = input("- Email'in sağ tarafı? \n "+ emailFirstPlace +"1@****** \n **** : ")
print("\n\n")
numberOfAccount = int(input("- Hesap sayısı: "))
password = getpass("Şifre: ")
baslangicSayisi = int(input("- Kaçıncı hesaptan başlansın?: "))
odulSayisi = int(input("Kaçıncı ödül alınsın? Seçenekler: \n1- 5 Gün\n2- 10 Gün\n3- 15 Gün\n4- 20 Gün\n5- 30 Gün\n6- 40 Gün\n7- 60 Gün\n8- 80 Gün\n9- 100 Gün\nSadece seçenek şeklinde (Örn:2) girin: "))
odulGunuArray = [5,10,15,20,30,40,60,80,100]

def odulTopla(odulSayisi):
    if numberOfAccount > 0:
        for i in range(baslangicSayisi, (baslangicSayisi + numberOfAccount)):
            email = emailFirstPlace + str(i) + "@" + emailType
            driver = webdriver.Chrome()
            link = "https://www.oasgames.com/?a=ucenter&m=login"
            driver.get(link)
            while True:
                try:
                    #driver.find_element(By.XPATH, "/html/body/div[2]/div[1]/div[1]/ul/li[3]/a").click()
                    #frame = driver.find_element(By.ID, "login_reg_page")
                    time.sleep(3)
                    #driver.switch_to.frame(frame)
                    driver.find_element(By.XPATH, "//*[@id='user_email']").send_keys(email)
                    time.sleep(1)
                    pyautogui.click(848,543)
                    time.sleep(0.5)
                    driver.find_element(By.XPATH, '//*[@id="user_password"]').send_keys(password)
                    time.sleep(0.5)
                    driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/div[2]/div[1]/a").click()
                    time.sleep(1)
                    link = "https://newserver79-lotr.oasgames.com/activity"
                    driver.get(link)
                    time.sleep(1)
                    #driver.switch_to.default_content()
                    break
                except Exception:
                    driver.refresh()
                    time.sleep(5)
                    continue
            while True:
                try:
                    driver.find_element(By.XPATH, '/html/body/div[2]/div[1]/div[5]/div[4]/div[1]/div[3]/ul/li['+str(odulSayisi)+']/a').click()
                    time.sleep(4)
                    driver.find_element(By.XPATH, "/html/body/div[2]/div[11]/div/div").click()
                    driver.find_element(By.CLASS_NAME, "close_alert11").click()
                    break
                except Exception:
                    time.sleep(1)
                    driver.refresh()
                    continue
            while True:
                try:
                    driver.find_element(By.XPATH, '/html/body/div[2]/div[20]/a[1]').click()
                    time.sleep(4)
                    driver.find_element(By.XPATH, "//li/span[text()='Takım Ödülü']").click()
                    f = open("C:/Users/EGEMEN ÖNDER/Desktop/SeleniumBots/ToplananKodlar.txt", "r")
                    time.sleep(1)
                    if(driver.find_element(By.CLASS_NAME, "code_list").text.__contains__("Toplam "+str(odulGunuArray[odulSayisi-1])+" Yoklama") 
                    and not f.read().__contains__(driver.find_element(By.CLASS_NAME, "code_list").text)):
                        with open("C:/Users/EGEMEN ÖNDER/Desktop/SeleniumBots/ToplananKodlar.txt", 'a', encoding='utf-8') as f:
                           print("Başarıyla Kod eklendi: " + driver.find_element(By.CLASS_NAME, "code_list").text)
                           f.write('\n' +str(i) + "- " +(driver.find_element(By.CLASS_NAME, "code_list").text))
                    f.close()
                    break
                except Exception:
                    time.sleep(1)
                    driver.refresh()
                    continue
            driver.close()
            time.sleep(2)     
    else:
        print("Hata! Hesap sayısı 0dan az olmamalıdır.")
        print("\n\n")
        os.system("PAUSE")

odulTopla(odulSayisi)