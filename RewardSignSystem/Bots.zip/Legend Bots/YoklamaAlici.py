from getpass import getpass
import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
import pyautogui
## Legend Online Helper için özel olarak geliştirilmiştir Bot 3
## Otomatik yoklama almak için yapılmıştır.
print("\n")
print("█░░ █▀▀ █▀▀ █▀▀ █▄░█ █▀▄   █▀█ █▄░█ █░░ █ █▄░█ █▀▀   █░█ █▀▀ █░░ █▀█ █▀▀ █▀█")
print("█▄▄ ██▄ █▄█ ██▄ █░▀█ █▄▀   █▄█ █░▀█ █▄▄ █ █░▀█ ██▄   █▀█ ██▄ █▄▄ █▀▀ ██▄ █▀▄")
print("\nYoklama Alma Botu Powered by AthenaSenior \n\n")
print("\nKod çoğaltılamaz veya değiştirilemez. Tespit edildiği takdirde adli işlemler başlatılır. Bol Farmlar dileriz..\n")
print("\n______________________________________________________________________________________________________________________\n")
emailFirstPlace = input("- Email'in sol tarafı? \n Örnek: asdas1@gmail.com, asdas2@gmail.com... ise 'asdas' girin. \n **** : ")
print("\n\n")
emailType = input("- Email'in sağ tarafı? \n "+ emailFirstPlace +"1@****** \n **** : ")
print("\n\n")
numberOfAccount = int(input("- Hesap sayısı: "))
password = getpass("Şifre: ")
baslangicSayisi = int(input("- Kaçıncı hesaptan başlansın?: "))
if numberOfAccount > 0:
    for i in range(baslangicSayisi, (baslangicSayisi + numberOfAccount)):
        email = emailFirstPlace + str(i) + "@" + emailType
        driver = webdriver.Chrome()
        link = "https://www.oasgames.com/?a=ucenter&m=login"
        driver.get(link)
        while True:
            try:
                #driver.find_element(By.XPATH, "/html/body/div[2]/div[1]/div[1]/ul/li[3]/a").click()
                #frame = driver.find_element(By.ID, "login_reg_page")
                time.sleep(3)
                #driver.switch_to.frame(frame)
                driver.find_element(By.XPATH, "//*[@id='user_email']").send_keys(email)
                time.sleep(1)
                pyautogui.click(848,543)
                time.sleep(0.5)
                driver.find_element(By.XPATH, '//*[@id="user_password"]').send_keys(password)
                time.sleep(0.5)
                driver.find_element(By.XPATH, "/html/body/div[2]/div[2]/div[2]/div[1]/a").click()
                time.sleep(1)
                link = "https://newserver79-lotr.oasgames.com/activity"
                driver.get(link)
                time.sleep(1)
                #driver.switch_to.default_content()
                break
            except Exception:
                #print(e)
                driver.refresh()
                time.sleep(1.5)
                continue
        while True:
            try:
                driver.find_element(By.CLASS_NAME, "date_btn_check").click()
                time.sleep(4)
                driver.find_element(By.XPATH, "/html/body/div[2]/div[12]/div/div/p").click()
                break
            except Exception:
                time.sleep(1)
                driver.refresh()
                continue
        driver.close()
        time.sleep(2)     
else:
    print("Hata! Hesap sayısı 0dan az olmamalıdır.")
    print("\n\n")
    os.system("PAUSE")